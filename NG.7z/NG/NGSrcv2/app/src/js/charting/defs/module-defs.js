'use strict';

function initializeChartingModule(logService) {
    if (logService) {
        logService.info("Charting Module Initialized!");
    }
}