'use strict';

function initializeBuildingBlocksModule(logService) {
    if (logService) {
        logService.info("Building Blocks (Logging and Exception Handling) Initialized!");
    }
}